#pragma once

#include <QObject>
#include <QSerialPort>
#include <QStringList>
#include <QVector>

#include "database.h"   // Database::ModeProfile

class PacemakerLink : public QObject {
    Q_OBJECT

public:
    explicit PacemakerLink(QObject *parent = nullptr);
    ~PacemakerLink() override;

    QStringList availablePorts() const;
    bool connectToDevice(const QString &portName, qint32 baudRate, QString *errorMessage = nullptr);
    void disconnectFromDevice();
    bool isConnected() const;

    void sendParameters(const Database::ModeProfile &profile);
    void requestParameters();

    void startEgramStream(quint8 channelMask);
    void stopEgramStream();

signals:
    void connected(const QString &port, qint32 baud);
    void disconnected();
    void errorOccurred(const QString &msg);

    void parametersWritten();
    void parametersReadBack(const Database::ModeProfile &profile);

    void egramSamplesReceived(const QVector<double> &atrial,
                              const QVector<double> &ventricular);

private slots:
    void handleReadyRead();
    void handleError(QSerialPort::SerialPortError e);

private:
    QByteArray buildSetParametersFrame(const Database::ModeProfile &p) const;
    QByteArray buildRequestParametersFrame() const;
    QByteArray buildStartEgramFrame(quint8 mask) const;
    QByteArray buildStopEgramFrame() const;

    void processIncomingBytes();
    void handleFrame(const QByteArray &frame);
    void handleParametersFrame(const QByteArray &frame);
    void handleEgramFrame(const QByteArray &frame);

    static quint16 readUInt16LE(const QByteArray &data, int offset);
    static void writeUInt16LE(QByteArray &data, int offset, quint16 value);

    static float readFloat32LE(const QByteArray &data, int offset);
    static void writeFloat32LE(QByteArray &data, int offset, float value);

    static quint8 modeToCode(const QString &mode);
    static QString codeToMode(quint8 code);

private:
    QSerialPort m_port;
    QByteArray m_rxBuffer;
};
