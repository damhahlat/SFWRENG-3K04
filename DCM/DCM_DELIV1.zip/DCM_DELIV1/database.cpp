#include "database.h"

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <QCryptographicHash>
#include <QStandardPaths>
#include <QDir>
#include <QDebug>

namespace Database {

static QSqlDatabase db;

// Hash password using SHA-256
static QString hashPw(const QString& pw) {
    return QString::fromUtf8(
        QCryptographicHash::hash(pw.toUtf8(), QCryptographicHash::Sha256).toHex()
        );
}

// Compute DB file path
QString path() {
    const auto baseDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir dir(baseDir);
    if (!dir.exists()) {
        dir.mkpath(QStringLiteral("."));
    }
    return dir.filePath(QStringLiteral("pacemaker_dcm.sqlite"));
}

// Ensure database is opened and schema exists
static bool ensureDb(QString* err = nullptr) {
    if (!db.isValid()) {
        db = QSqlDatabase::addDatabase(QStringLiteral("QSQLITE"));
        db.setDatabaseName(path());
    }

    if (!db.isOpen()) {
        if (!db.open()) {
            if (err) *err = QStringLiteral("Failed to open database: %1").arg(db.lastError().text());
            return false;
        }
    }

    // Create tables if not exist
    QSqlQuery q(db);

    // Users table
    if (!q.exec(
            "CREATE TABLE IF NOT EXISTS users ("
            "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "  username TEXT UNIQUE NOT NULL,"
            "  password_hash TEXT NOT NULL"
            ");"
            )) {
        if (err) *err = QStringLiteral("Failed to create users table: %1").arg(q.lastError().text());
        return false;
    }

    // Mode profiles:
    // Deliverable 2 needs amplitude, pulse width and sensitivity for A and V.
    if (!q.exec(
            "CREATE TABLE IF NOT EXISTS mode_profiles ("
            "  user_id INTEGER NOT NULL,"
            "  mode TEXT NOT NULL,"
            "  lrl INTEGER,"
            "  url INTEGER,"
            "  a_amp REAL,"
            "  a_pw REAL,"
            "  v_amp REAL,"
            "  v_pw REAL,"
            "  arp INTEGER,"
            "  vrp INTEGER,"
            "  a_sens REAL,"
            "  v_sens REAL,"
            "  PRIMARY KEY (user_id, mode),"
            "  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE"
            ");"
            )) {
        if (err) *err = QStringLiteral("Failed to create mode_profiles table: %1").arg(q.lastError().text());
        return false;
    }

    return true;
}

// Public init() used by existing code
bool init(QString* err) {
    return ensureDb(err);
}

// User API

bool registerUser(const QString& username, const QString& password, QString* err) {
    if (!ensureDb(err)) return false;

    if (username.trimmed().isEmpty()) {
        if (err) *err = QStringLiteral("Username cannot be empty.");
        return false;
    }
    if (password.isEmpty()) {
        if (err) *err = QStringLiteral("Password cannot be empty.");
        return false;
    }

    // Check if username exists
    QSqlQuery q(db);
    q.prepare("SELECT id FROM users WHERE username = ?");
    q.addBindValue(username.trimmed());
    if (!q.exec()) {
        if (err) *err = QStringLiteral("Database error: %1").arg(q.lastError().text());
        return false;
    }
    if (q.next()) {
        if (err) *err = QStringLiteral("Username already exists.");
        return false;
    }

    // Insert new user
    QSqlQuery ins(db);
    ins.prepare("INSERT INTO users(username, password_hash) VALUES(?, ?)");
    ins.addBindValue(username.trimmed());
    ins.addBindValue(hashPw(password));
    if (!ins.exec()) {
        if (err) *err = QStringLiteral("Failed to register user: %1").arg(ins.lastError().text());
        return false;
    }

    return true;
}

bool loginUser(const QString& username, const QString& password, QString* err) {
    if (!ensureDb(err)) return false;

    QSqlQuery q(db);
    q.prepare("SELECT password_hash FROM users WHERE username = ?");
    q.addBindValue(username.trimmed());
    if (!q.exec()) {
        if (err) *err = QStringLiteral("Database error: %1").arg(q.lastError().text());
        return false;
    }
    if (!q.next()) {
        if (err) *err = QStringLiteral("User not found.");
        return false;
    }

    const QString stored = q.value(0).toString();
    if (stored != hashPw(password)) {
        if (err) *err = QStringLiteral("Invalid username or password.");
        return false;
    }

    return true;
}

int userId(const QString& username) {
    QString err;
    if (!ensureDb(&err)) {
        qWarning() << "Failed to ensure DB in userId:" << err;
        return -1;
    }

    QSqlQuery q(db);
    q.prepare("SELECT id FROM users WHERE username = ?");
    q.addBindValue(username.trimmed());
    if (!q.exec()) {
        qWarning() << "Database error in userId:" << q.lastError().text();
        return -1;
    }
    if (!q.next()) return -1;
    return q.value(0).toInt();
}

// Mode profile API

static void bindOptInt(QSqlQuery& q, const std::optional<int>& v) {
    if (v.has_value()) q.addBindValue(*v);
    else q.addBindValue(QVariant(QVariant::Int));
}

static void bindOptDouble(QSqlQuery& q, const std::optional<double>& v) {
    if (v.has_value()) q.addBindValue(*v);
    else q.addBindValue(QVariant(QVariant::Double));
}

bool upsertProfile(const ModeProfile& p, QString* err) {
    if (!ensureDb(err)) return false;

    QSqlQuery q(db);
    q.prepare(
        "INSERT INTO mode_profiles ("
        "  user_id, mode, lrl, url, a_amp, a_pw, v_amp, v_pw, arp, vrp, a_sens, v_sens"
        ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?) "
        "ON CONFLICT(user_id, mode) DO UPDATE SET "
        "  lrl = excluded.lrl,"
        "  url = excluded.url,"
        "  a_amp = excluded.a_amp,"
        "  a_pw = excluded.a_pw,"
        "  v_amp = excluded.v_amp,"
        "  v_pw = excluded.v_pw,"
        "  arp = excluded.arp,"
        "  vrp = excluded.vrp,"
        "  a_sens = excluded.a_sens,"
        "  v_sens = excluded.v_sens;"
        );

    q.addBindValue(p.userId);
    q.addBindValue(p.mode);
    bindOptInt(q, p.lrl);
    bindOptInt(q, p.url);
    bindOptDouble(q, p.aAmp);
    bindOptDouble(q, p.aPw);
    bindOptDouble(q, p.vAmp);
    bindOptDouble(q, p.vPw);
    bindOptInt(q, p.arp);
    bindOptInt(q, p.vrp);
    bindOptDouble(q, p.aSens);
    bindOptDouble(q, p.vSens);

    if (!q.exec()) {
        if (err) *err = QStringLiteral("Failed to save mode profile: %1").arg(q.lastError().text());
        return false;
    }

    return true;
}

std::optional<ModeProfile> getProfile(int userId, const QString& mode, QString* err) {
    if (!ensureDb(err)) return std::nullopt;

    QSqlQuery q(db);
    q.prepare(
        "SELECT lrl, url, a_amp, a_pw, v_amp, v_pw, arp, vrp, a_sens, v_sens "
        "FROM mode_profiles WHERE user_id = ? AND mode = ?"
        );
    q.addBindValue(userId);
    q.addBindValue(mode);
    if (!q.exec()) {
        if (err) *err = QStringLiteral("Failed to query mode profile: %1").arg(q.lastError().text());
        return std::nullopt;
    }

    if (!q.next()) {
        // No profile saved yet
        return std::nullopt;
    }

    ModeProfile p;
    p.userId = userId;
    p.mode = mode;

    auto getOptI = [&](int index) -> std::optional<int> {
        const QVariant v = q.value(index);
        if (v.isNull()) return std::nullopt;
        return v.toInt();
    };
    auto getOptD = [&](int index) -> std::optional<double> {
        const QVariant v = q.value(index);
        if (v.isNull()) return std::nullopt;
        return v.toDouble();
    };

    p.lrl   = getOptI(0);
    p.url   = getOptI(1);
    p.aAmp  = getOptD(2);
    p.aPw   = getOptD(3);
    p.vAmp  = getOptD(4);
    p.vPw   = getOptD(5);
    p.arp   = getOptI(6);
    p.vrp   = getOptI(7);
    p.aSens = getOptD(8);
    p.vSens = getOptD(9);

    return p;
}

} // namespace Database
