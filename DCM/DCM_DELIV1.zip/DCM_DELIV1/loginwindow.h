#pragma once

#include <QMainWindow>
#include <QString>

#include "serialtestdialog.h"
#include "pacemakerlink.h"
#include "database.h"  // Database::ModeProfile

class ParameterForm;
class EgramWidget;

namespace Ui { class MainWindow; }

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(int userId, const QString &username, QWidget *parent = nullptr);
    ~MainWindow() override;

private slots:
    void onNewPatient();
    void onSetClock();
    void onExportBradyParams();
    void onExportTemporaryParams();
    void onQuit();

    void onAbout();
    void onOpenDbFolder();
    void onOpenSerialTest();

    void onConnectDevice();
    void onDisconnectDevice();
    void onApplyToDevice();
    void onReadFromDevice();

    void onLinkConnected(const QString &portName, qint32 baudRate);
    void onLinkDisconnected();
    void onLinkError(const QString &message);
    void onParametersFromDevice(const Database::ModeProfile &profile);

private:
    Ui::MainWindow *ui;
    int userId_;
    QString username_;

    ParameterForm *form_{nullptr};
    EgramWidget *egram_{nullptr};
    PacemakerLink *link_{nullptr};

    Database::ModeProfile lastSentProfile_;
    bool haveLastSentProfile_{false};

    QString lastClockSet_;

    void buildMenus();
    QString buildReportHtml(const QString &reportName) const;

    QString appModel() const { return "DCM-APP-001"; }
    QString appVersion() const { return "1.0.0"; }
    QString dcmSerial() const { return "DCM-SN-0001"; }
    QString institution() const { return "McMaster University"; }
};
