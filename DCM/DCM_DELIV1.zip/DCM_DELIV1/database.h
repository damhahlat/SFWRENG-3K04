#pragma once

#include <QString>
#include <optional>
#include <QMap>

namespace Database {

// Represents a single mode profile for a given user.
struct ModeProfile {
    int userId{};
    QString mode; // "AOO", "VOO", "AAI", "VVI", "AOOR", "VOOR", "AAIR", "VVIR"

    // Rate limits and refractory periods
    std::optional<int> lrl;   // Lower Rate Limit (ppm)
    std::optional<int> url;   // Upper Rate Limit (ppm)
    std::optional<int> arp;   // Atrial Refractory Period (ms)
    std::optional<int> vrp;   // Ventricular Refractory Period (ms)

    // Atrial / Ventricular amplitude and pulse width
    std::optional<double> aAmp; // Atrial Amplitude (V)
    std::optional<double> aPw;  // Atrial Pulse Width (ms)
    std::optional<double> vAmp; // Ventricular Amplitude (V)
    std::optional<double> vPw;  // Ventricular Pulse Width (ms)

    // NEW for Deliverable 2: Sensitivity per chamber
    std::optional<double> aSens; // Atrial Sensitivity (V)
    std::optional<double> vSens; // Ventricular Sensitivity (V)
};

// Returns the path to the SQLite database file (used in About dialog and for debugging).
QString path();

// Initialize database (kept for compatibility with existing calls in main.cpp / loginwindow.cpp)
bool init(QString* err = nullptr);

// User management
bool registerUser(const QString& username, const QString& password, QString* err = nullptr);
bool loginUser(const QString& username, const QString& password, QString* err = nullptr);
int  userId(const QString& username); // -1 if not found

// Mode profile management
bool upsertProfile(const ModeProfile& p, QString* err = nullptr);
std::optional<ModeProfile> getProfile(int userId, const QString& mode, QString* err = nullptr);

} // namespace Database
