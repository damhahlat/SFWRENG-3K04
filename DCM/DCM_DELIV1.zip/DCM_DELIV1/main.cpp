#include <QApplication>
#include <QStyleFactory>
#include <QPalette>
#include <QMessageBox>

#include "loginwindow.h"
#include "mainwindow.h"
#include "database.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    // Consistent, modern Fusion style
    QApplication::setStyle(QStyleFactory::create("Fusion"));

    // Light theme with readable contrast
    QPalette pal;
    pal.setColor(QPalette::Window, QColor(245,245,247));
    pal.setColor(QPalette::WindowText, Qt::black);
    pal.setColor(QPalette::Base, Qt::white);
    pal.setColor(QPalette::AlternateBase, QColor(240,240,240));
    pal.setColor(QPalette::ToolTipBase, Qt::white);
    pal.setColor(QPalette::ToolTipText, Qt::black);
    pal.setColor(QPalette::Text, Qt::black);
    pal.setColor(QPalette::Button, QColor(245,245,247));
    pal.setColor(QPalette::ButtonText, Qt::black);
    pal.setColor(QPalette::Highlight, QColor(0,120,215));
    pal.setColor(QPalette::HighlightedText, Qt::white);
    app.setPalette(pal);

    // Start DB
    QString err;
    if (!Database::init(&err)) {
        QMessageBox::critical(nullptr, "DCM", "Failed to open DB: " + err);
        return 1;
    }

    // Login
    LoginWindow login;
    if (login.exec() != QDialog::Accepted)
        return 0;

    const QString user = login.username();
    const int userId = Database::userId(user);

    MainWindow w(userId, user);
    w.show();

    return app.exec();
}
