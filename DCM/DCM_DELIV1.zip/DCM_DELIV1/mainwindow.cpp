#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>
#include <QInputDialog>
#include <QFileDialog>
#include <QDateTime>
#include <QDesktopServices>
#include <QDir>
#include <QUrl>
#include <QDebug>

#include "parameterform.h"
#include "database.h"

// ---------------------------------------------------------------------------
// Constructor / destructor
// ---------------------------------------------------------------------------

MainWindow::MainWindow(int userId, const QString &username, QWidget *parent)
    : QMainWindow(parent),
    ui(new Ui::MainWindow),
    userId_(userId),
    username_(username)
{
    ui->setupUi(this);

    // Create ParameterForm and insert into parametersLayout
    form_ = new ParameterForm(userId_, this);

    QVBoxLayout *paramsLayout = ui->parametersLayout;
    if (paramsLayout) {
        paramsLayout->insertWidget(1, form_);
    }

    // Pacemaker link
    link_ = new PacemakerLink(this);

    connect(link_, &PacemakerLink::connected,
            this, &MainWindow::onLinkConnected);
    connect(link_, &PacemakerLink::disconnected,
            this, &MainWindow::onLinkDisconnected);
    connect(link_, &PacemakerLink::errorOccurred,
            this, &MainWindow::onLinkError);
    connect(link_, &PacemakerLink::parametersReadBack,
            this, &MainWindow::onParametersFromDevice);

    // Serial test dialog (optional utility)
    serialTestDialog_ = new SerialTestDialog(this);

    buildMenus();

    // About Tab info
    ui->appModelLabel->setText(appModel());
    ui->appVersionLabel->setText(appVersion());
    ui->dcmSerialLabel->setText(dcmSerial());
    ui->institutionLabel->setText(institution());
    ui->dbPathLabel->setText(Database::path());
}

MainWindow::~MainWindow()
{
    delete ui;
}

// ---------------------------------------------------------------------------
// Menus
// ---------------------------------------------------------------------------

void MainWindow::buildMenus()
{
    // ---------------- File menu ----------------
    QMenu *fileMenu = menuBar()->addMenu("File");

    QAction *newPatientAct = fileMenu->addAction("New Patient");
    connect(newPatientAct, &QAction::triggered, this, &MainWindow::onNewPatient);

    QAction *setClockAct = fileMenu->addAction("Set Clock...");
    connect(setClockAct, &QAction::triggered, this, &MainWindow::onSetClock);

    QAction *exportBradyAct = fileMenu->addAction("Export Brady Parameters (HTML)...");
    connect(exportBradyAct, &QAction::triggered, this, &MainWindow::onExportBradyParams);

    QAction *exportTempAct = fileMenu->addAction("Export Temporary Parameters (HTML)...");
    connect(exportTempAct, &QAction::triggered, this, &MainWindow::onExportTemporaryParams);

    fileMenu->addSeparator();

    QAction *quitAct = fileMenu->addAction("Quit");
    connect(quitAct, &QAction::triggered, this, &MainWindow::onQuit);

    // ---------------- Tools menu ----------------
    QMenu *toolsMenu = menuBar()->addMenu("Tools");

    QAction *openDbFolderAct = toolsMenu->addAction("Open DB Folder");
    connect(openDbFolderAct, &QAction::triggered, this, &MainWindow::onOpenDbFolder);

    QAction *serialTestAct = toolsMenu->addAction("Serial Port Test...");
    connect(serialTestAct, &QAction::triggered, this, &MainWindow::onOpenSerialTest);

    toolsMenu->addSeparator();

    QAction *connectDevAct = toolsMenu->addAction("Connect to Pacemaker...");
    connect(connectDevAct, &QAction::triggered, this, &MainWindow::onConnectDevice);

    QAction *disconnectDevAct = toolsMenu->addAction("Disconnect from Pacemaker");
    connect(disconnectDevAct, &QAction::triggered, this, &MainWindow::onDisconnectDevice);

    toolsMenu->addSeparator();

    QAction *applyAct = toolsMenu->addAction("Apply Parameters to Pacemaker");
    connect(applyAct, &QAction::triggered, this, &MainWindow::onApplyToDevice);

    QAction *readAct = toolsMenu->addAction("Read / Verify Parameters from Pacemaker");
    connect(readAct, &QAction::triggered, this, &MainWindow::onReadFromDevice);

    // ---------------- Help menu ----------------
    QMenu *helpMenu = menuBar()->addMenu("Help");

    QAction *aboutAct = helpMenu->addAction("About");
    connect(aboutAct, &QAction::triggered, this, &MainWindow::onAbout);
}

// ---------------------------------------------------------------------------
// File menu actions
// ---------------------------------------------------------------------------

void MainWindow::onNewPatient()
{
    int ret = QMessageBox::question(
        this,
        "New Patient",
        "This will clear all parameter fields.\nContinue?"
        );
    if (ret == QMessageBox::Yes)
        form_->clearAll();
}

void MainWindow::onSetClock()
{
    lastClockSet_ = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    ui->clockStatusLabel->setText("Last clock set: " + lastClockSet_);
}

void MainWindow::onExportBradyParams()
{
    QString html = buildReportHtml("Brady Parameters Report");
    QString file = QFileDialog::getSaveFileName(
        this, "Save HTML Report", "report.html", "*.html");
    if (file.isEmpty()) return;

    QFile f(file);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        QMessageBox::warning(this, "Error", "Failed to write file.");
        return;
    }
    f.write(html.toUtf8());
    f.close();
    QMessageBox::information(this, "Saved", "Report exported.");
}

void MainWindow::onExportTemporaryParams()
{
    QString html = buildReportHtml("Temporary Parameters Report");
    QString file = QFileDialog::getSaveFileName(
        this, "Save HTML Report", "temp_report.html", "*.html");
    if (file.isEmpty()) return;

    QFile f(file);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        QMessageBox::warning(this, "Error", "Failed to write file.");
        return;
    }
    f.write(html.toUtf8());
    f.close();
    QMessageBox::information(this, "Saved", "Report exported.");
}

void MainWindow::onQuit()
{
    close();
}

// ---------------------------------------------------------------------------
// Help menu
// ---------------------------------------------------------------------------

void MainWindow::onAbout()
{
    QMessageBox::information(
        this,
        "About",
        "Pacemaker DCM\nMcMaster University\nDeliverable 2"
        );
}

// ---------------------------------------------------------------------------
// Tools
// ---------------------------------------------------------------------------

void MainWindow::onOpenDbFolder()
{
    QDesktopServices::openUrl(QUrl::fromLocalFile(Database::path()));
}

void MainWindow::onOpenSerialTest()
{
    serialTestDialog_->show();
    serialTestDialog_->raise();
}

// ---------------------------------------------------------------------------
// Device connection
// ---------------------------------------------------------------------------

void MainWindow::onConnectDevice()
{
    QStringList ports = link_->availablePorts();
    if (ports.isEmpty()) {
        QMessageBox::warning(this, "No Ports", "No COM ports found.");
        return;
    }

    bool ok = false;
    QString port = QInputDialog::getItem(
        this, "Select Port", "Port:", ports, 0, false, &ok);
    if (!ok) return;

    QString err;
    if (!link_->connectToDevice(port, 115200, &err)) {
        QMessageBox::warning(this, "Error", err);
    }
}

void MainWindow::onDisconnectDevice()
{
    link_->disconnectFromDevice();
}

void MainWindow::onLinkConnected(const QString &port, qint32 baud)
{
    QString msg = QString("Connected to %1 @ %2 baud").arg(port).arg(baud);
    ui->paramStatus->setText(msg);
}

void MainWindow::onLinkDisconnected()
{
    ui->paramStatus->setText("Disconnected from device");
}

void MainWindow::onLinkError(const QString &message)
{
    ui->paramStatus->setText("Error: " + message);
}

// ---------------------------------------------------------------------------
// Apply / Read / Verify
// ---------------------------------------------------------------------------

void MainWindow::onApplyToDevice()
{
    if (!link_->isConnected()) {
        QMessageBox::warning(this, "Not connected", "Connect to device first.");
        return;
    }

    Database::ModeProfile p;
    QString err;

    if (!form_->tryBuildProfile(&p, &err)) {
        QMessageBox::warning(this, "Invalid", err);
        return;
    }

    // Save to DB
    if (!Database::upsertProfile(p, &err)) {
        QMessageBox::warning(this, "Database Error", err);
        return;
    }

    lastSentProfile_ = p;
    haveLastSentProfile_ = true;

    link_->sendParameters(p);

    ui->paramStatus->setText("Parameters sent to device");
}

void MainWindow::onReadFromDevice()
{
    if (!link_->isConnected()) {
        QMessageBox::warning(this, "Not connected", "Connect to device first.");
        return;
    }

    ui->paramStatus->setText("Requesting parameters...");
    link_->requestParameters();
}

void MainWindow::onParametersFromDevice(const Database::ModeProfile &dev)
{
    if (!haveLastSentProfile_) {
        ui->paramStatus->setText("Device returned parameters (no reference to verify).");
        return;
    }

    const auto &a = lastSentProfile_;
    bool match =
        (a.mode == dev.mode) &&
        (a.lrl == dev.lrl) &&
        (a.url == dev.url) &&
        (a.arp == dev.arp) &&
        (a.vrp == dev.vrp) &&
        (a.aAmp == dev.aAmp) &&
        (a.vAmp == dev.vAmp) &&
        (a.aPw == dev.aPw) &&
        (a.vPw == dev.vPw);

    if (match) {
        ui->paramStatus->setText("Verified: Device matches DCM parameters.");
    } else {
        ui->paramStatus->setText("Mismatch: Device parameters differ.");
    }
}

// ---------------------------------------------------------------------------
// HTML report builder
// ---------------------------------------------------------------------------

QString MainWindow::buildReportHtml(const QString &name) const
{
    auto vals = form_->currentValuesAsText();

    QString html;
    html += "<html><body>";
    html += "<h2>" + name + "</h2>";
    html += "<table border='1' cellspacing='0' cellpadding='4'>";

    for (auto it = vals.begin(); it != vals.end(); ++it) {
        html += "<tr><td><b>" + it.key() + "</b></td><td>" + it.value() + "</td></tr>";
    }

    html += "</table></body></html>";
    return html;
}
