#include "parameterform.h"
#include "ui_parameterform.h"
#include "database.h"

#include <QMessageBox>
#include <QDebug>

ParameterForm::ParameterForm(int userId, QWidget* parent)
    : QWidget(parent),
    ui(new Ui::ParameterForm),
    userId_(userId),
    settings_("McMaster", "PacemakerDCM")
{
    ui->setupUi(this);

    restoreMode();
    applyDefaults();

    connect(ui->saveButton, &QPushButton::clicked, this, &ParameterForm::onSave);
    connect(ui->loadButton, &QPushButton::clicked, this, &ParameterForm::onLoad);
    connect(ui->clearButton, &QPushButton::clicked, this, &ParameterForm::onClear);

    auto all = findChildren<QWidget*>();
    for (auto w : all) {
        connect(w, &QWidget::destroyed, this, &ParameterForm::onFieldChanged);
    }
}

ParameterForm::~ParameterForm() {
    delete ui;
}

void ParameterForm::clearAll() {
    applyDefaults();
}

QString ParameterForm::mode() const {
    return ui->modeCombo->currentText();
}

void ParameterForm::applyDefaults() {
    ui->lrlSpin->setValue(60);
    ui->urlSpin->setValue(120);
    ui->aAmpSpin->setValue(3.5);
    ui->aPwSpin->setValue(0.4);
    ui->vAmpSpin->setValue(3.5);
    ui->vPwSpin->setValue(0.4);
    ui->arpSpin->setValue(250);
    ui->vrpSpin->setValue(320);
    ui->aSensSpin->setValue(2.5);
    ui->vSensSpin->setValue(2.5);
}

void ParameterForm::rememberMode(const QString& m) const {
    settings_.setValue("lastMode", m);
}

void ParameterForm::restoreMode() {
    QString m = settings_.value("lastMode", "AOO").toString();
    int idx = ui->modeCombo->findText(m);
    if (idx >= 0)
        ui->modeCombo->setCurrentIndex(idx);
}

bool ParameterForm::checkAmplitudeStep(double v, QString* why) const {
    // Amplitude increments must be multiples of 0.1
    double scaled = v * 10.0;
    if (qFuzzyCompare(scaled, static_cast<int>(scaled)))
        return true;

    if (why)
        *why = "Amplitude must be in steps of 0.1 V.";
    return false;
}

bool ParameterForm::validate(QString* err) const {
    if (ui->lrlSpin->value() >= ui->urlSpin->value()) {
        if (err) *err = "LRL must be < URL.";
        return false;
    }

    QString why;
    if (!checkAmplitudeStep(ui->aAmpSpin->value(), &why)) {
        if (err) *err = why;
        return false;
    }
    if (!checkAmplitudeStep(ui->vAmpSpin->value(), &why)) {
        if (err) *err = why;
        return false;
    }

    return true;
}

bool ParameterForm::tryBuildProfile(Database::ModeProfile* out, QString* errMsg) const {
    QString e;
    if (!validate(&e)) {
        if (errMsg) *errMsg = e;
        return false;
    }

    Database::ModeProfile p;
    p.userId = userId_;
    p.mode   = ui->modeCombo->currentText();

    p.lrl  = ui->lrlSpin->value();
    p.url  = ui->urlSpin->value();
    p.arp  = ui->arpSpin->value();
    p.vrp  = ui->vrpSpin->value();

    p.aAmp = ui->aAmpSpin->value();
    p.aPw  = ui->aPwSpin->value();
    p.vAmp = ui->vAmpSpin->value();
    p.vPw  = ui->vPwSpin->value();

    p.aSens = ui->aSensSpin->value();
    p.vSens = ui->vSensSpin->value();

    *out = p;
    return true;
}

void ParameterForm::onFieldChanged() {
    QString err;
    bool ok = validate(&err);
    reflectValidity();
    if (!ok)
        emit statusMessage(err);
}

void ParameterForm::reflectValidity() {
    // Could highlight invalid widgets if desired
}

void ParameterForm::onSave() {
    QString err;
    Database::ModeProfile p;
    if (!tryBuildProfile(&p, &err)) {
        QMessageBox::warning(this, "Invalid", err);
        return;
    }

    rememberMode(p.mode);

    if (!Database::upsertProfile(p, &err)) {
        QMessageBox::warning(this, "DB Error", err);
        return;
    }

    emit statusMessage("Parameters saved.");
}

void ParameterForm::onLoad() {
    QString err;
    auto p = Database::getProfile(userId_, mode(), &err);
    if (!p.has_value()) {
        QMessageBox::warning(this, "No profile", "Nothing saved for this mode.");
        return;
    }
    auto m = *p;

    ui->lrlSpin->setValue(m.lrl.value_or(60));
    ui->urlSpin->setValue(m.url.value_or(120));
    ui->arpSpin->setValue(m.arp.value_or(250));
    ui->vrpSpin->setValue(m.vrp.value_or(320));
    ui->aAmpSpin->setValue(m.aAmp.value_or(3.5));
    ui->aPwSpin->setValue(m.aPw.value_or(0.4));
    ui->vAmpSpin->setValue(m.vAmp.value_or(3.5));
    ui->vPwSpin->setValue(m.vPw.value_or(0.4));
    ui->aSensSpin->setValue(m.aSens.value_or(2.5));
    ui->vSensSpin->setValue(m.vSens.value_or(2.5));

    emit statusMessage("Loaded profile.");
}

void ParameterForm::onClear() {
    clearAll();
}
