#pragma once

#include <QWidget>
#include <QSettings>
#include <QMap>
#include <QString>

#include "database.h"   // Database::ModeProfile

QT_BEGIN_NAMESPACE
namespace Ui { class ParameterForm; }
QT_END_NAMESPACE

class ParameterForm : public QWidget {
    Q_OBJECT

public:
    explicit ParameterForm(int userId, QWidget* parent = nullptr);
    ~ParameterForm() override;

    // Build a profile from UI. Returns false if validation fails.
    bool tryBuildProfile(Database::ModeProfile* out, QString* errMsg = nullptr) const;

    // Used by report builder to get "LRL: 60 ppm", etc.
    QMap<QString, QString> currentValuesAsText() const;

signals:
    void statusMessage(const QString& msg);

public slots:
    void clearAll();

private slots:
    void onFieldChanged();
    void onSave();
    void onLoad();
    void onClear();

private:
    Ui::ParameterForm* ui;
    int userId_;
    QSettings settings_;

    bool validate(QString* err) const;
    void reflectValidity();
    QString mode() const;

    void applyDefaults();
    void rememberMode(const QString& m) const;
    void restoreMode();

    bool checkAmplitudeStep(double v, QString* why) const;
};
