#pragma once
#include <QWidget>
#include <QSettings>
#include <QMap>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class ParameterForm; }
QT_END_NAMESPACE

class ParameterForm : public QWidget {
    Q_OBJECT
public:
    explicit ParameterForm(int userId, QWidget* parent = nullptr);
    ~ParameterForm() override;

    QMap<QString, QString> currentValuesAsText() const;

signals:
    void statusMessage(const QString& msg);

public slots:
    void clearAll();

private slots:
    void onFieldChanged();
    void onSave();
    void onLoad();
    void onClear();

private:
    Ui::ParameterForm* ui;
    int userId_;
    QSettings settings_{"McMaster", "PacemakerDCM"};

    bool validate(QString* err) const;
    void reflectValidity();
    QString mode() const;
    void applyDefaults();
    void rememberMode(const QString& m);
    void restoreMode();
    void applyModeVisibility(const QString& m);
    bool checkAmplitudeStep(double v, QString* why) const;

    // helper to show/hide a field and its label regardless of object names
    void setFieldAndLabelVisible(QWidget* field, bool visible) const;
};
