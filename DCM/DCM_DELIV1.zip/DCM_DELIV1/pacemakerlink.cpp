#include "pacemakerlink.h"
#include <QSerialPortInfo>
#include <QtMath>
#include <QDebug>

// Message type values (byte 1)
namespace {
constexpr quint8 MSG_SET_PARAMS    = 0x01;
constexpr quint8 MSG_REQ_PARAMS    = 0x02;
constexpr quint8 MSG_PARAMS_RESP   = 0x03;
constexpr quint8 MSG_EGRAM_SAMPLES = 0x04;
constexpr quint8 MSG_START_EGRAM   = 0x07;
constexpr quint8 MSG_STOP_EGRAM    = 0x08;

constexpr int FRAME_SIZE = 32;
}

// ---------------------------------------------------------------------------
// Constructor / destructor
// ---------------------------------------------------------------------------

PacemakerLink::PacemakerLink(QObject *parent)
    : QObject(parent)
{
    connect(&m_port, &QSerialPort::readyRead,
            this, &PacemakerLink::handleReadyRead);

#if QT_VERSION >= QT_VERSION_CHECK(5, 15, 0)
    connect(&m_port, &QSerialPort::errorOccurred,
            this, &PacemakerLink::handleError);
#else
    connect(&m_port,
            static_cast<void (QSerialPort::*)(QSerialPort::SerialPortError)>(&QSerialPort::error),
            this, &PacemakerLink::handleError);
#endif
}

PacemakerLink::~PacemakerLink()
{
    if (m_port.isOpen())
        m_port.close();
}

// ---------------------------------------------------------------------------
// Port enumeration
// ---------------------------------------------------------------------------

QStringList PacemakerLink::availablePorts() const
{
    QStringList list;
    const auto ports = QSerialPortInfo::availablePorts();
    for (const auto &info : ports)
        list << info.portName();
    return list;
}

// ---------------------------------------------------------------------------
// Connect / disconnect
// ---------------------------------------------------------------------------

bool PacemakerLink::connectToDevice(const QString &portName,
                                    qint32 baudRate,
                                    QString *error)
{
    if (m_port.isOpen())
        m_port.close();

    m_port.setPortName(portName);
    m_port.setBaudRate(baudRate);
    m_port.setDataBits(QSerialPort::Data8);
    m_port.setParity(QSerialPort::NoParity);
    m_port.setStopBits(QSerialPort::OneStop);
    m_port.setFlowControl(QSerialPort::NoFlowControl);

    if (!m_port.open(QIODevice::ReadWrite)) {
        QString msg = QString("Failed to open %1: %2")
        .arg(portName, m_port.errorString());
        if (error) *error = msg;
        emit errorOccurred(msg);
        return false;
    }

    emit connected(portName, baudRate);
    return true;
}

void PacemakerLink::disconnectFromDevice()
{
    if (m_port.isOpen()) {
        m_port.close();
        emit disconnected();
    }
}

bool PacemakerLink::isConnected() const
{
    return m_port.isOpen();
}

// ---------------------------------------------------------------------------
// High-level commands
// ---------------------------------------------------------------------------

void PacemakerLink::sendParameters(const Database::ModeProfile &p)
{
    if (!m_port.isOpen()) {
        emit errorOccurred("Port not open");
        return;
    }

    QByteArray frame = buildSetParametersFrame(p);
    m_port.write(frame);
    m_port.flush();
    emit parametersWritten();
}

void PacemakerLink::requestParameters()
{
    if (!m_port.isOpen()) {
        emit errorOccurred("Port not open");
        return;
    }

    QByteArray frame = buildRequestParametersFrame();
    m_port.write(frame);
    m_port.flush();
}

void PacemakerLink::startEgramStream(quint8 mask)
{
    if (!m_port.isOpen()) {
        emit errorOccurred("Port not open");
        return;
    }

    QByteArray f = buildStartEgramFrame(mask);
    m_port.write(f);
    m_port.flush();
}

void PacemakerLink::stopEgramStream()
{
    if (!m_port.isOpen()) {
        emit errorOccurred("Port not open");
        return;
    }

    QByteArray f = buildStopEgramFrame();
    m_port.write(f);
    m_port.flush();
}

// ---------------------------------------------------------------------------
// Reading incoming bytes
// ---------------------------------------------------------------------------

void PacemakerLink::handleReadyRead()
{
    m_rxBuffer.append(m_port.readAll());
    processIncomingBytes();
}

void PacemakerLink::handleError(QSerialPort::SerialPortError e)
{
    if (e != QSerialPort::NoError)
        emit errorOccurred(m_port.errorString());
}

// ---------------------------------------------------------------------------
// Frame builders
// ---------------------------------------------------------------------------

QByteArray PacemakerLink::buildSetParametersFrame(const Database::ModeProfile &p) const
{
    QByteArray frame(FRAME_SIZE, 0);

    frame[1] = MSG_SET_PARAMS;
    frame[2] = modeToCode(p.mode);

    frame[3] = static_cast<char>(p.lrl.value_or(0));   // LRL
    frame[4] = 0;                                      // MSR unused

    writeFloat32LE(frame, 5,  static_cast<float>(p.aAmp.value_or(0.0)));
    writeFloat32LE(frame, 9,  static_cast<float>(p.vAmp.value_or(0.0)));
    writeFloat32LE(frame, 13, static_cast<float>(p.aPw.value_or(0.0)));
    writeFloat32LE(frame, 17, static_cast<float>(p.vPw.value_or(0.0)));

    writeUInt16LE(frame, 21, static_cast<quint16>(p.vrp.value_or(0)));
    writeUInt16LE(frame, 23, static_cast<quint16>(p.arp.value_or(0)));

    writeUInt16LE(frame, 26, 0);   // AVD not used
    frame[25] = 0;                 // HysteresisTime
    frame[28] = 0;                 // ReactionTime
    frame[29] = 0;                 // ResponseFactor
    frame[30] = 0;                 // RecoveryTime

    return frame;
}

QByteArray PacemakerLink::buildRequestParametersFrame() const
{
    QByteArray frame(FRAME_SIZE, 0);
    frame[1] = MSG_REQ_PARAMS;
    return frame;
}

QByteArray PacemakerLink::buildStartEgramFrame(quint8 mask) const
{
    QByteArray frame(FRAME_SIZE, 0);
    frame[1] = MSG_START_EGRAM;
    frame[2] = mask;
    return frame;
}

QByteArray PacemakerLink::buildStopEgramFrame() const
{
    QByteArray frame(FRAME_SIZE, 0);
    frame[1] = MSG_STOP_EGRAM;
    return frame;
}

// ---------------------------------------------------------------------------
// Incoming frame processing
// ---------------------------------------------------------------------------

void PacemakerLink::processIncomingBytes()
{
    while (m_rxBuffer.size() >= FRAME_SIZE) {
        QByteArray frame = m_rxBuffer.left(FRAME_SIZE);
        m_rxBuffer.remove(0, FRAME_SIZE);
        handleFrame(frame);
    }
}

void PacemakerLink::handleFrame(const QByteArray &frame)
{
    if (frame.size() != FRAME_SIZE)
        return;

    quint8 type = static_cast<quint8>(frame[1]);

    switch (type) {
    case MSG_PARAMS_RESP:
        handleParametersFrame(frame);
        break;
    case MSG_EGRAM_SAMPLES:
        handleEgramFrame(frame);
        break;
    default:
        break;
    }
}

void PacemakerLink::handleParametersFrame(const QByteArray &f)
{
    Database::ModeProfile p;
    p.userId = -1;

    p.mode = codeToMode(static_cast<quint8>(f[2]));

    quint8 lrl = static_cast<quint8>(f[3]);
    if (lrl == 0) p.lrl.reset();
    else p.lrl = lrl;

    float aAmp = readFloat32LE(f, 5);
    float vAmp = readFloat32LE(f, 9);
    float aPw  = readFloat32LE(f, 13);
    float vPw  = readFloat32LE(f, 17);

    if (!qFuzzyIsNull(aAmp)) p.aAmp = aAmp;
    if (!qFuzzyIsNull(vAmp)) p.vAmp = vAmp;
    if (!qFuzzyIsNull(aPw))  p.aPw  = static_cast<int>(qRound(aPw));
    if (!qFuzzyIsNull(vPw))  p.vPw  = static_cast<int>(qRound(vPw));

    quint16 vrp = readUInt16LE(f, 21);
    quint16 arp = readUInt16LE(f, 23);

    if (vrp != 0) p.vrp = vrp;
    if (arp != 0) p.arp = arp;

    emit parametersReadBack(p);
}

void PacemakerLink::handleEgramFrame(const QByteArray &)
{
    // You can fill this later when Simulink egram format arrives
}

// ---------------------------------------------------------------------------
// Endianness helpers
// ---------------------------------------------------------------------------

quint16 PacemakerLink::readUInt16LE(const QByteArray &d, int off)
{
    quint8 lo = static_cast<quint8>(d[off]);
    quint8 hi = static_cast<quint8>(d[off+1]);
    return (hi << 8) | lo;
}

void PacemakerLink::writeUInt16LE(QByteArray &d, int off, quint16 v)
{
    d[off]   = static_cast<char>(v & 0xFF);
    d[off+1] = static_cast<char>((v >> 8) & 0xFF);
}

float PacemakerLink::readFloat32LE(const QByteArray &d, int off)
{
    float f;
    unsigned char *p = reinterpret_cast<unsigned char*>(&f);
    p[0] = d[off];
    p[1] = d[off+1];
    p[2] = d[off+2];
    p[3] = d[off+3];
    return f;
}

void PacemakerLink::writeFloat32LE(QByteArray &d, int off, float v)
{
    const unsigned char *p = reinterpret_cast<const unsigned char*>(&v);
    d[off]   = p[0];
    d[off+1] = p[1];
    d[off+2] = p[2];
    d[off+3] = p[3];
}

// ---------------------------------------------------------------------------
// Mode mapping
// ---------------------------------------------------------------------------

quint8 PacemakerLink::modeToCode(const QString &m)
{
    if (m == "AOO")  return 0;
    if (m == "VOO")  return 1;
    if (m == "AAI")  return 2;
    if (m == "VVI")  return 3;
    if (m == "AOOR") return 4;
    if (m == "VOOR") return 5;
    if (m == "AAIR") return 6;
    if (m == "VVIR") return 7;
    return 0xFF;
}

QString PacemakerLink::codeToMode(quint8 c)
{
    switch (c) {
    case 0: return "AOO";
    case 1: return "VOO";
    case 2: return "AAI";
    case 3: return "VVI";
    case 4: return "AOOR";
    case 5: return "VOOR";
    case 6: return "AAIR";
    case 7: return "VVIR";
    default: return "AOO";
    }
}
