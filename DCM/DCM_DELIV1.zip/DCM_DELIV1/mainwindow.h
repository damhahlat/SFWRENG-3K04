#pragma once
#include <QMainWindow>
class ParameterForm;
class EgramWidget;

namespace Ui { class MainWindow; }

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(int userId, const QString& username, QWidget* parent = nullptr);
    ~MainWindow() override;

private slots:
    // File menu
    void onNewPatient();
    void onSetClock();
    void onExportBradyParams();
    void onExportTemporaryParams();
    void onQuit();
    // Help
    void onAbout();
    // Misc
    void onOpenDbFolder();

private:
    Ui::MainWindow* ui;
    int userId_{-1};
    QString username_;
    ParameterForm* form_{nullptr};
    EgramWidget* egram_{nullptr};

    QString appModel() const { return "DCM-APP-001"; }
    QString appVersion() const { return "1.0.0"; }
    QString dcmSerial() const { return "DCM-SN-0001"; }
    QString institution() const { return "McMaster University"; }
    QString lastClockSet_;  // store most recent device time

    void buildMenus();
    QString buildReportHtml(const QString& reportName) const;
    bool exportHtmlToPdf(const QString& html, const QString& defaultName);
};
