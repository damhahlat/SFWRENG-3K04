from dataclasses import dataclass


@dataclass
class User:
    username: str
    password: str  # For a real system you would not store plain text.
