import tkinter as tk
from tkinter import ttk


class BaseFrame(ttk.Frame):
    """
    Base frame for all views, so we have a common style hook.
    """

    def __init__(self, parent, controller=None, **kwargs):
        super().__init__(parent, padding=10, **kwargs)
        self.controller = controller
